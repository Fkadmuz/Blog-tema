<footer class="footer">
    <div class="container">
        <div class="footer-custom">
            <h5><?php bloginfo('name') ?></h5>
            <p><?php bloginfo('description') ?></p>
        </div>
        <div class="footer-wp">
            <?php wp_footer() ?>
        </div>
    </div>
</footer>
</body>
</html>