# Tema personalizado para Wordpress
Este tema deve ser utilizado dentro do diretório **wp-content/themes** da sua instalação do WordPress.

## Estrutura básica de Arquivos
```
+-- style.css       // configurações do tema: nome, autor...
+-- index.php       // página principal do tema
+-- header.php      // cabeçalho do tema
+-- footer.php      // rodapé do tema
+-- functions.php   // funções gerais do tema
+-- page.php        // página única
```
